import os
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:21'
import sys
import warnings
import json

proj_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
sys.path.append(proj_path)

script_dir = os.path.dirname(os.path.abspath(__file__))
params_path = os.path.join(script_dir, "params.json")

outputs_dir = os.path.normpath(os.path.join(script_dir, "../../../outputs/coco_ovd/coop_found_models/"))

with open(params_path, "r") as f:
    params = json.load(f)

detectron2_dir = params["detectron2_dir"]
visualize = params["visualize"]
data_split = params["data_split"]
cfg_file = params["cfg_file"]
rcnn_weight_dir = params["rcnn_weight_dir"]
sam_checkpoint = params["sam_checkpoint"]
gdino_checkpoint = params["gdino_checkpoint"]

os.environ['DETECTRON2_DATASETS'] = detectron2_dir

import torch
torch.cuda.empty_cache()
import detectron2.data.transforms as T


from scripts.open_vocab_detection.evaluate_method.utils import  get_ovd_id_to_coco_id
from scripts.open_vocab_detection.evaluate_method.evaluator_loop import inference_mcnn_clip

from pathlib import Path
from detectron2.data import build_detection_test_loader, get_detection_dataset_dicts, DatasetMapper
from detectron2.evaluation import print_csv_format
from segment_anything.utils.transforms import ResizeLongestSide


from datasets.register_coco_ovd_dataset import coco_meta # to register the OVD datasets
from scripts.open_vocab_detection.coco_eval_utils.custom_coco_eval import CustomCOCOEvaluator

warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)

Path(outputs_dir).mkdir(parents=True, exist_ok=True)

device = "cuda" if torch.cuda.is_available() else "cpu"

ovd_id_to_coco_id = get_ovd_id_to_coco_id()



test_loader = build_detection_test_loader(
    dataset = get_detection_dataset_dicts(names = data_split, filter_empty=False),
    mapper= DatasetMapper(
        is_train = False,
        augmentations=[
            T.ResizeShortestEdge(short_edge_length=800, max_size=1333),
        ],
        image_format="BGR",
    ),
    num_workers=4,
)

coco_evaluator = CustomCOCOEvaluator(dataset_name = data_split)

param_dict = {}
param_dict["out_dir"] = outputs_dir
param_dict["data_split"] = data_split
param_dict["device"] = device
param_dict["cfg_file"] = cfg_file
param_dict["ovd_id_to_coco_id"] = ovd_id_to_coco_id
param_dict["rcnn_weight_dir"] = rcnn_weight_dir


if __name__ == "__main__":
    results = inference_mcnn_clip(test_loader, coco_evaluator, param_dict)
    print_csv_format(results)
