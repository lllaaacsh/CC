import os
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:32'
import sys
import torch
import json
from loguru import logger # 直接使用 loguru，不使用 logging
import numpy as np
from PIL import Image
from tqdm import tqdm
import torch.nn.functional as F
import detectron2.data.transforms as T
import pycocotools.mask as mask_util
import datetime
import time
from sklearn.preprocessing import MinMaxScaler # 添加 MinMaxScaler 导入

from detectron2.config import LazyConfig, instantiate
from detectron2.engine import default_setup
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.data import build_detection_test_loader, get_detection_dataset_dicts, DatasetMapper, MetadataCatalog, DatasetCatalog
from detectron2.structures import Instances, Boxes, BoxMode
from detectron2.evaluation import inference_on_dataset
from pathlib import Path
# from scripts.open_vocab_detection.evaluate_method.utils import get_text_prompt_for_g_dino, get_ovd_id_to_coco_id # 假设 utils 路径已在 sys.path 中
# 使用你的 utils.py 路径，这里我直接导入了，如果你的结构不同，请修改
from scripts.open_vocab_detection.evaluate_method.utils import get_ovd_id_to_coco_id, get_clip_preds 

# from scripts.open_vocab_detection.evaluate_method.load_models import load_fully_supervised_trained_model # 假设 load_models 路径已在 sys.path 中
from scripts.open_vocab_detection.evaluate_method.load_models import load_fully_supervised_trained_model, load_clip_model # 从你的 load_models.py 中导入

from scripts.open_vocab_detection.coco_eval_utils.custom_coco_eval import CustomCOCOEvaluator
from scripts.open_vocab_detection.coco_eval_utils.coco_ovd_split import categories_seen, categories_unseen

# This import is necessary to trigger dataset registration in register_coco_ovd_dataset.py
# It MUST happen before we try to check its metadata.
from datasets.register_coco_ovd_dataset import coco_meta

import open_clip
import cv2 # 用于图像处理，如果你需要的话
import torch.nn as nn # 用于检查nn.ModuleList


CLIP_BATCH = 8 

def _inference_maskrcnn_siglip(rcnn_model, inputs, param_dict):
    clip_model = param_dict["clip_model"]
    device = param_dict["device"]
    text_features = param_dict["clip_text_features"]
    preprocess = param_dict["preprocess"]
    ovd_id_to_coco_id = get_ovd_id_to_coco_id()


    rcnn_model.eval()
    clip_model.eval()

    rcnn_model.eval()

    if not isinstance(rcnn_model.roi_heads.box_predictor, nn.ModuleList):  # baseline, non-centernet
        # self.supervised_rcnn.proposal_generator.nms_thresh = self.discovery_nms_thresh
        rcnn_model.proposal_generator.nms_thresh = 0.9
    else:
        # self.supervised_rcnn.proposal_generator.nms_thresh_test = self.discovery_nms_thresh
        rcnn_model.proposal_generator.nms_thresh_train = 0.9
        rcnn_model.proposal_generator.nms_thresh_test = 0.9

    if isinstance(rcnn_model.roi_heads.box_predictor, nn.ModuleList):
        box_predictors = rcnn_model.roi_heads.box_predictor
    else:
        box_predictors = [rcnn_model.roi_heads.box_predictor]

    for box_predictor in box_predictors:
        box_predictor.allow_novel_classes_during_inference = True
        box_predictor.allow_novel_classes_during_training = True
        box_predictor.test_topk_per_image = 300
        box_predictor.test_nms_thresh = 0.5
        box_predictor.test_score_thresh = 0.0001

    outputs = rcnn_model(inputs)
    rcnn_boxes = outputs[0]["instances"].pred_boxes.tensor.to("cpu") # format: (x1, y1, x2, y2)
    rcnn_scores = outputs[0]["instances"].scores.to("cpu")
    rcnn_classes = outputs[0]["instances"].pred_classes.to("cpu")

    bg_boxes_idxs = rcnn_classes == 80
    bg_boxes = rcnn_boxes[bg_boxes_idxs].to("cpu")

    known_boxes = rcnn_boxes[~bg_boxes_idxs].to("cpu")
    known_scores = rcnn_scores[~bg_boxes_idxs].to("cpu")
    known_classes = rcnn_classes[~bg_boxes_idxs].to("cpu")

    img = inputs[0]['image']
    new_height = img.shape[1]
    new_width = img.shape[2]
    object_crop_1x_list = []
    selected_idx = []
    for bbox_idx, bbox in enumerate(bg_boxes):
        x1, y1, x2, y2 = bbox

        x1 = int(x1 * new_width / inputs[0]['width'])
        x2 = int(x2 * new_width / inputs[0]['width'])

        y1 = int(y1 * new_height / inputs[0]['height'])
        y2 = int(y2 * new_height / inputs[0]['height'])

        cropped_image = img[:, y1:y2, x1:x2]
        cropped_img_arr = cropped_image.permute(1, 2, 0).numpy()

        if cropped_img_arr.shape[0] > 0 and cropped_img_arr.shape[1] > 0:
            cropped_img_arr = cv2.cvtColor(cropped_img_arr, cv2.COLOR_BGR2RGB) # convert to RGB
            img_pil = Image.fromarray(cropped_img_arr)
            image = preprocess(img_pil).unsqueeze(0).to(device)

            object_crop_1x_list.append(image)
            selected_idx.append(bbox_idx)
    
    selected_idx = torch.tensor(selected_idx)
    all_scores, all_indices = [], []
    
    # 2. 分批送进 CLIP
    for start in range(0, len(object_crop_1x_list), CLIP_BATCH):
        end = start + CLIP_BATCH
        batch_tensor = torch.cat(object_crop_1x_list[start:end], dim=0)  # [B,3,H,W]
    
        # 用 AMP 进一步省显存
        with torch.cuda.amp.autocast():
            scores_clip, indices_clip = get_clip_preds(
                batch_tensor, clip_model, text_features
            )
    
        # 立即转到 CPU，释放显存
        all_scores.append(scores_clip.cpu())
        all_indices.append(indices_clip.cpu())
    
        del batch_tensor
        torch.cuda.empty_cache()
    
    # 3. 合并结果
    scores_clip = torch.cat(all_scores, dim=0)
    indices_clip = torch.cat(all_indices, dim=0)

    bg_boxes = bg_boxes[selected_idx]
    bg_scores = scores_clip.squeeze(1).to("cpu")
    bg_classes = indices_clip.squeeze(1).to("cpu")

    bg_classes = torch.tensor( [ovd_id_to_coco_id[i.item()] for i in bg_classes] )

    combined_rcnn_boxes = torch.cat([known_boxes, bg_boxes], dim = 0)
    combined_rcnn_scores = torch.cat([known_scores, bg_scores], dim = 0)
    combined_rcnn_classes = torch.cat([known_classes, bg_classes], dim = 0)
    h, w = inputs[0]['height'], inputs[0]['width']


    result = Instances((h, w))
    result.pred_boxes = Boxes(combined_rcnn_boxes)
    result.scores = combined_rcnn_scores
    result.pred_classes = combined_rcnn_classes

    final_outputs = []
    curr_output = {}
    curr_output['instances'] = result
    final_outputs.append(curr_output)

    return final_outputs


# 类似于你提供的 inference 函数，作为评估的主循环
@torch.no_grad()
def evaluate_maskrcnn_siglip_performance(data_loader, evaluator, rcnn_model, param_dict):
    evaluator.reset()
    logger.info("###\n### Start inference on {} batches for Mask R-CNN + SigLIP\n###".format(len(data_loader)))

    total = len(data_loader)
    num_warmup = min(5, total - 1)
    start_time = time.perf_counter() # 确保导入 time

    for idx, inputs in enumerate(tqdm(data_loader, desc="Processing images for evaluation")):
        if idx == num_warmup:
            start_time = time.perf_counter()

        # 调用我们新的推理函数
        outputs = _inference_maskrcnn_siglip(rcnn_model, inputs, param_dict)
        if torch.cuda.is_available():
            torch.cuda.synchronize()

        evaluator.process(inputs, outputs)

        iters_after_start = idx + 1 - num_warmup * int(idx >= num_warmup)
        total_seconds_per_iter = (time.perf_counter() - start_time) / iters_after_start
        if idx >= num_warmup * 2:
            eta = datetime.timedelta(seconds=int(total_seconds_per_iter * (total - idx - 1)))
            pass

    total_time = time.perf_counter() - start_time
    total_time_str = str(datetime.timedelta(seconds=total_time))
    logger.info("Total inference time (Mask R-CNN + SigLIP): {} ({:.6f} s / iter per device)".format(
        total_time_str, total_time / (total - num_warmup)
    ))

    logger.info("Evaluation complete. Computing final metrics...")
    results = evaluator.evaluate() # 调用 CustomCOCOEvaluator 的 evaluate 方法
    logger.info("Final Evaluation Results (Mask R-CNN + SigLIP):")
    logger.info(results)
    return results


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    proj_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
    sys.path.append(proj_path)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(script_dir, "mparam.json")

    outputs_dir = os.path.normpath(os.path.join(script_dir, "../../../outputs/coco_ovd/coop_found_models/"))
    Path(outputs_dir).mkdir(parents=True, exist_ok=True)

    with open(params_path, "r") as f:
        params = json.load(f)

    cfg_file = params["cfg_file"]
    rcnn_weight_dir = params["rcnn_weight_dir"]
    dataset_name_for_eval = params["data_split"]

    from datasets.register_coco_ovd_dataset import coco_meta

    rcnn_model, cfg_for_meta = load_fully_supervised_trained_model(cfg_file, rcnn_weight_dir)

    clip_model, preprocess, clip_text_features = load_clip_model(device, None) 
    logger.info(f"Loaded CLIP model.")


    mapper = DatasetMapper(
        is_train=False,
        augmentations=[
            T.ResizeShortestEdge(short_edge_length=800, max_size=1333),
        ],
        image_format="BGR",
    )
    test_loader = build_detection_test_loader(
        dataset = get_detection_dataset_dicts(names = dataset_name_for_eval, filter_empty=False),
        mapper= mapper,
        num_workers=4
    )



    coco_evaluator = CustomCOCOEvaluator(dataset_name=dataset_name_for_eval)

    param_dict = {
        "device": device,
        "clip_model": clip_model,
        "preprocess": preprocess,
        "clip_text_features": clip_text_features,
        "data_split": dataset_name_for_eval,
        "out_dir": outputs_dir,
    }

    results = evaluate_maskrcnn_siglip_performance(test_loader, coco_evaluator, rcnn_model, param_dict)

    if results is not None:
        from detectron2.evaluation import print_csv_format
        print_csv_format(results)


if __name__ == "__main__":
    main()