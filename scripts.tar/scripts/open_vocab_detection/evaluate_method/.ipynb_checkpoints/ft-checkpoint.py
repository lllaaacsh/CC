import os
import sys
import cv2
import json
import torch
import torch.nn as nn
import torch.optim as optim
from loguru import logger
from torch.utils.data import Dataset, DataLoader, Subset
from PIL import Image
from tqdm import tqdm
import open_clip
from detectron2.config import LazyConfig, instantiate
from detectron2.engine import default_setups
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.data import build_detection_train_loader, get_detection_dataset_dicts, DatasetMapper
from utils import finetune_clip_model  #seperated into utils
import detectron2.data.transforms as T
import matplotlib.pyplot as plt
import torch.nn.functional as F
import torchvision.transforms as transforms
import torch.multiprocessing as mp
import torchvision.transforms.functional as TF





def truncate_dataloader(dataloader, num_batches):
    for batch_idx, batch in enumerate(dataloader):
        if batch_idx >= num_batches:
            break
        yield batch
        

def save_detected_objects(images, targets, batch_idx):
    """
    在训练过程中存储 Mask R-CNN 检测到的目标
    images: 输入图像（Tensor 格式）
    targets: 目标标签，包括 'boxes' 和 'labels'
    batch_idx: 训练的 batch 索引
    """
    for img_idx, (image, target) in enumerate(zip(images, targets)):
        image_pil = F.to_pil_image(image.cpu())  # 转换为 PIL Image
        boxes = target["boxes"].detach().cpu().numpy()  # 确保在 CPU 上
        labels = target["labels"].detach().cpu().numpy()

        for obj_idx, (box, label) in enumerate(zip(boxes, labels)):
            x1, y1, x2, y2 = map(int, box)

            # 裁剪目标区域
            cropped_obj = image_pil.crop((x1, y1, x2, y2))

            # 保存图片
            image_filename = f"cropped_dataset/images/{batch_idx}_{img_idx}_{obj_idx}.jpg"
            cropped_obj.save(image_filename)

            # 保存标签
            label_filename = f"cropped_dataset/labels/{batch_idx}_{img_idx}_{obj_idx}.txt"
            with open(label_filename, "w") as f:
                f.write(str(label))  # 存储类别

            print(f"Saved: {image_filename}, Label: {label_filename}")


def extract_cropped_images_and_labels(inputs, rcnn_model, device, preprocess, coco_id_name_map, batch_idx, output_dir="cropped_dataset"):
    rcnn_model.eval()
    with torch.no_grad():
        outputs = rcnn_model(inputs)

    # 获取检测到的目标类别
    rcnn_boxes = outputs[0]["instances"].pred_boxes.tensor.to("cuda") if len(outputs[0]["instances"]) > 0 else torch.tensor([])
    rcnn_classes = outputs[0]["instances"].pred_classes.to("cuda") if len(outputs[0]["instances"]) > 0 else torch.tensor([])

    # 如果没有检测到目标，直接返回 None
    if rcnn_classes.numel() == 0:
        print("No objects detected, skipping image.")
        return None, None

    img = inputs[0]["image"].to(device)
    new_height, new_width = img.shape[1], img.shape[2]
    object_crops_list = []
    selected_idx = []

    for bbox_idx, bbox in enumerate(rcnn_boxes):
        x1, y1, x2, y2 = bbox.int()

        # 调整裁剪区域的坐标
        x1 = max(0, int(x1 * new_width / inputs[0]['width']))
        x2 = min(new_width, int(x2 * new_width / inputs[0]['width']))
        y1 = max(0, int(y1 * new_height / inputs[0]['height']))
        y2 = min(new_height, int(y2 * new_height / inputs[0]['height']))

        # 确保裁剪区域有效
        if x2 > x1 and y2 > y1:
            cropped_image = img[:, y1:y2, x1:x2]
            cropped_img_arr = cropped_image.permute(1, 2, 0).cpu().numpy()

            if cropped_img_arr.shape[0] > 0 and cropped_img_arr.shape[1] > 0:
                # 确保图像是BGR格式
                if cropped_img_arr.shape[2] == 3:
                    cropped_img_arr = cv2.cvtColor(cropped_img_arr, cv2.COLOR_BGR2RGB)  # 转换为 RGB
                img_pil = Image.fromarray(cropped_img_arr)
                image = preprocess(img_pil).unsqueeze(0).to(device)

                object_crops_list.append(image)
                # 使用 coco_id_name_map 将类别索引映射为类别名称
                class_name = coco_id_name_map.get(rcnn_classes[bbox_idx].item())
                selected_idx.append(class_name)

    if object_crops_list:
        cropped_img_arr = torch.cat(object_crops_list, dim=0)
        return cropped_img_arr, selected_idx
    else:
        return None, None
        


def custom_collate_fn(batch):
    # 过滤掉 None 数据项
    batch = [item for item in batch if item[0] is not None and item[1] is not None]
    if not batch:
        return None  # 如果过滤后没有有效数据，返回 None

    # 使用默认的 collate_fn 处理剩余的数据
    return torch.utils.data.dataloader.default_collate(batch)



# 定义加载 CLIP 模型的函数
def load_clip_model(device):
    clip_model, _, preprocess = open_clip.create_model_and_transforms('ViT-SO400M-14-SigLIP', pretrained='webli')
    tokenizer = open_clip.get_tokenizer('ViT-SO400M-14-SigLIP')
    clip_model = clip_model.to(device)
    return clip_model, tokenizer, preprocess


# 定义加载 Faster R-CNN 模型的函数
def load_fully_supervised_trained_model(cfg_file, weight_dir):
    # Load the model weights of supervised training phase
    opts = [f'train.output_dir={weight_dir}', f'train.init_checkpoint={weight_dir}/model_final.pth']

    cfg = LazyConfig.load(cfg_file)
    cfg = LazyConfig.apply_overrides(cfg, opts)
    default_setup(cfg, None)

    model = instantiate(cfg.model)
    model.to(cfg.train.device)

    DetectionCheckpointer(model).load(cfg.train.init_checkpoint)
    return model, cfg


# 定义裁剪图像的数据集类
class CroppedImageDataset(Dataset):
    def __init__(self, images, labels, preprocess):
        self.images = images
        self.labels = labels
        self.preprocess = preprocess

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        while True:
            image = self.images[idx]
            label = self.labels[idx]

            # 确保 image 是一个 PIL 图像对象
            if isinstance(image, torch.Tensor):
                image = transforms.ToPILImage()(image)

            # 应用预处理
            image = self.preprocess(image)

            # 检查 label 是否为 None
            if label is None:
                # 如果 label 是 None，跳过该数据项
                idx = (idx + 1) % len(self.images)
                continue

            # 如果 label 不是 None，返回有效的数据
            return image, label




def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    proj_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
    sys.path.append(proj_path)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(script_dir, "tparams.json")
    with open(params_path, "r") as f:
        params = json.load(f)

    cfg_file = params["cfg_file"]
    rcnn_weight_dir = params["rcnn_weight_dir"]
    data_split = params["data_split"]
    coco_id_name_map = {
        1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorcycle', 5: 'airplane', 6: 'bus', 7: 'train', 8: 'truck', 9: 'boat', 10: 'traffic light',
        11: 'fire hydrant', 13: 'stop sign', 14: 'parking meter', 15: 'bench', 16: 'bird', 17: 'cat', 18: 'dog', 19: 'horse', 20: 'sheep',
        21: 'cow', 22: 'elephant', 23: 'bear', 24: 'zebra', 25: 'giraffe', 27: 'backpack', 28: 'umbrella', 31: 'handbag', 32: 'tie', 33: 'suitcase',
        34: 'frisbee', 35: 'skis', 36: 'snowboard', 37: 'sports ball', 38: 'kite', 39: 'baseball bat', 40: 'baseball glove', 41: 'skateboard',
        42: 'surfboard', 43: 'tennis racket', 44: 'bottle', 46: 'wine glass', 47: 'cup', 48: 'fork', 49: 'knife', 50: 'spoon', 51: 'bowl',
        52: 'banana', 53: 'apple', 54: 'sandwich', 55: 'orange', 56: 'broccoli', 57: 'carrot', 58: 'hot dog', 59: 'pizza', 60: 'donut',
        61: 'cake', 62: 'chair', 63: 'couch', 64: 'potted plant', 65: 'bed', 67: 'dining table', 70: 'toilet', 72: 'tv', 73: 'laptop',
        74: 'mouse', 75: 'remote', 76: 'keyboard', 77: 'cell phone', 78: 'microwave', 79: 'oven', 80: 'toaster', 81: 'sink',
        82: 'refrigerator', 84: 'book', 85: 'clock', 86: 'vase', 87: 'scissors', 88: 'teddy bear', 89: 'hair drier', 90: 'toothbrush',100:'background'
    }


    # 加载 CLIP 模型
    clip_model, tokenizer, preprocess = load_clip_model(device)
    clip_model = clip_model.to(device)

    # 加载 Faster R-CNN 模型
    rcnn_model, cfg = load_fully_supervised_trained_model(cfg_file, rcnn_weight_dir)
    rcnn_model.to(device)

    # 创建 Dataset 和 DataLoader
    data_loader = build_detection_train_loader(
        dataset=get_detection_dataset_dicts(names=data_split, filter_empty=False),
        mapper=DatasetMapper(
            is_train=True,
            augmentations=[
                T.ResizeShortestEdge(short_edge_length=800, max_size=1333),
            ],
            image_format="BGR",
        ),
        total_batch_size=32,
        num_workers=0,
    )
    d_size = 1000
    truncated_loader = truncate_dataloader(data_loader, d_size)

    # 从标注文件中提取裁剪图像及其标签
    cropped_images_list = []
    selected_idx_list = []

    for batch_idx, batch in enumerate(tqdm(truncated_loader, desc="Processing batches", unit="batch")):
        # 将每个输入字典中的张量移动到设备
        inputs = [{k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in item.items()} for item in batch]
        cropped_images, selected_idx = extract_cropped_images_and_labels(inputs, rcnn_model, device, preprocess, coco_id_name_map, batch_idx)
        if cropped_images is not None and selected_idx is not None:
            cropped_images_list.append(cropped_images)
            selected_idx_list.append(selected_idx)

    # 合并裁剪图像和标签
    if cropped_images_list and selected_idx_list:
        cropped_images = torch.cat(cropped_images_list, dim=0)
        selected_idx = [item for sublist in selected_idx_list for item in sublist] 

            # 保存裁剪后的图像和标签
    output_dir = "cropped_dataset"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    for batch_idx, (cropped_images, selected_idx) in enumerate(zip(cropped_images_list, selected_idx_list)):
        for img_idx, (image, label) in enumerate(zip(cropped_images, selected_idx)):
            image_filename = os.path.join(output_dir, f"images/{batch_idx}_{img_idx}.jpg")
            label_filename = os.path.join(output_dir, f"labels/{batch_idx}_{img_idx}.txt")
            image_pil = TF.to_pil_image(image.cpu())
            image_pil.save(image_filename)
            with open(label_filename, "w") as f:
                f.write(str(label))

    
        # 创建裁剪图像的数据集和 DataLoader
        dataset = CroppedImageDataset(cropped_images, selected_idx, preprocess)
        dataloader = DataLoader(dataset, batch_size=32, shuffle=True, num_workers=0, pin_memory=True, collate_fn=custom_collate_fn)

        # 微调 CLIP 模型
        finetuned_clip_model = finetune_clip_model(clip_model, dataloader,tokenizer, d_size, device, epochs=10, lr=1e-5, alpha=0.5)
    else:
        logger.info("No valid cropped images found. Skipping fine-tuning.")

if __name__ == "__main__":
    main()