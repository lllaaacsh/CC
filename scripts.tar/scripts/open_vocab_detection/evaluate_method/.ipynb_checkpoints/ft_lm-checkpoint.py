import os
import sys
import cv2
import json
import torch
import torch.nn as nn
import torch.optim as optim
from loguru import logger
from torch.utils.data import Dataset, DataLoader, Subset
from PIL import Image
from tqdm import tqdm
import open_clip
from detectron2.config import LazyConfig, instantiate
from detectron2.engine import default_setup
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.data import build_detection_train_loader, get_detection_dataset_dicts, DatasetMapper
import detectron2.data.transforms as T
import matplotlib.pyplot as plt
import torch.nn.functional as F
import torchvision.transforms.functional as TF
import torchvision.transforms as transforms
import torch.multiprocessing as mp
import numpy as np
from torchvision.transforms import Resize, ToTensor, Normalize, Compose

import matplotlib.pyplot as plt
import matplotlib.patches as patches




class LabelmeDataset(Dataset):
    def __init__(self, root_dir, preprocess):
        """
        初始化数据集
        :param root_dir: 数据集的根目录
        :param preprocess: 图像预处理函数
        """
        self.root_dir = root_dir
        self.preprocess = preprocess
        self.data = []
        
        # 遍历每个子文件夹
        for folder_id in range(40):  # 从0000到0039文件夹
            folder_path = os.path.join(root_dir, f'{folder_id:04d}')
            if os.path.isdir(folder_path):
                # 计算起始和结束ID
                start_id = folder_id * 1000
                end_id = (folder_id + 1) * 1000
                # 遍历每个图像文件
                for image_id in range(start_id, end_id):  
                    image_path = os.path.join(folder_path, f'{image_id:06d}.jpg')
                    if os.path.exists(image_path):
                        self.data.append(image_path)
                    else:
                        print(f"Image not found: {image_path}")  # 打印不存在的图像路径

        if not self.data:
            print(f"No images found in {root_dir}. Please check the directory and image naming format.")
            raise ValueError("No images found in the specified directory.")

    def __len__(self):
        """
        返回数据集的大小
        """
        return len(self.data)

    def __getitem__(self, idx):
        """
        根据索引idx获取图像和标签
        """
        image_path = self.data[idx]
        image = Image.open(image_path).convert('RGB')
        resize_transform = Resize((800, 1333))
        image = resize_transform(image)
        image = TF.to_tensor(image)  # 转换为 Tensor
        return image  # 返回图像



def truncate_dataloader(dataloader, num_batches):
    for batch_idx, batch in enumerate(dataloader):
        if batch_idx >= num_batches:
            break
        yield batch


def save_detected_objects(images, targets, batch_idx):
    """
    在训练过程中存储 Mask R-CNN 检测到的目标
    images: 输入图像（Tensor 格式）
    targets: 目标标签，包括 'boxes' 和 'labels'
    batch_idx: 训练的 batch 索引
    """
    for img_idx, (image, target) in enumerate(zip(images, targets)):
        image_pil = F.to_pil_image(image.cpu())  # 转换为 PIL Image
        boxes = target["boxes"].detach().cpu().numpy()  # 确保在 CPU 上
        labels = target["labels"].detach().cpu().numpy()

        for obj_idx, (box, label) in enumerate(zip(boxes, labels)):
            x1, y1, x2, y2 = map(int, box)

            # 裁剪目标区域
            cropped_obj = image_pil.crop((x1, y1, x2, y2))

            # 保存图片
            image_filename = f"cropped_dataset/images/{batch_idx}_{img_idx}_{obj_idx}.jpg"
            cropped_obj.save(image_filename)

            # 保存标签
            label_filename = f"cropped_dataset/labels/{batch_idx}_{img_idx}_{obj_idx}.txt"
            with open(label_filename, "w") as f:
                f.write(str(label))  # 存储类别

            print(f"Saved: {image_filename}, Label: {label_filename}")

def custom_collate_fn(batch):
    filtered_batch = [item for item in batch if item[0] is not None and item[1] is not None]
    if not filtered_batch:
        print("No valid data items in the batch.")
        return None
    return torch.utils.data.dataloader.default_collate(filtered_batch)

# 定义一个函数，用于从 RCNN 输出中提取裁剪图像及其标签
# def extract_cropped_images_and_labels(inputs, rcnn_model, device, preprocess, coco_id_name_map, batch_idx):
#     rcnn_model.eval()
#     if not isinstance(rcnn_model.roi_heads.box_predictor, nn.ModuleList):  # baseline, non-centernet
#         rcnn_model.proposal_generator.nms_thresh = 0.9
#     else:
#         rcnn_model.proposal_generator.nms_thresh_train = 0.9
#         rcnn_model.proposal_generator.nms_thresh_test = 0.9

#     if isinstance(rcnn_model.roi_heads.box_predictor, nn.ModuleList):
#         box_predictors = rcnn_model.roi_heads.box_predictor
#     else:
#         box_predictors = [rcnn_model.roi_heads.box_predictor]

#     for box_predictor in box_predictors:
#         box_predictor.allow_novel_classes_during_inference = True
#         box_predictor.allow_novel_classes_during_training = True
#         box_predictor.test_topk_per_image = 10
#         box_predictor.test_nms_thresh = 0.5
#         box_predictor.test_score_thresh = 0.0001

#     with torch.no_grad():
#         # 假设 inputs 是包含图像和元数据的列表
#         for item in inputs:
#             image = item['image']
#             image = image.permute(1, 2, 0).cpu().numpy()  # 转换为 (H, W, C) 格式
#             image = (image * 255).astype(np.uint8)  # 确保数据类型为 uint8
        
#             # 显示图像以检查是否失真
#             plt.imshow(image)
#             plt.axis('off')
#             plt.show()
        
#             # 将图像数据类型转换回 float32，如果模型需要
#             image = image.astype(np.float32) / 255.0
#             item['image'] = torch.from_numpy(image).permute(2, 0, 1)  # 转换回 (C, H, W) 格式
#         outputs = rcnn_model(inputs)

#     instances = outputs[0]["instances"]
#     num_instances = instances.pred_classes.numel()
#     print(f"Number of instances detected: {num_instances}")

#     # 获取检测到的目标类别
#     rcnn_boxes = outputs[0]["instances"].pred_boxes.tensor.to("cuda") if len(outputs[0]["instances"]) > 0 else torch.tensor([])
#     rcnn_classes = outputs[0]["instances"].pred_classes.to("cuda") if len(outputs[0]["instances"]) > 0 else torch.tensor([])


#     # 如果没有检测到目标，直接返回 None
#     if rcnn_classes.numel() == 0:
#         print("No objects detected, skipping image.")
#         return None, None

#     img = inputs[0]["image"].to(device)
#     new_height, new_width = img.shape[1], img.shape[2]
#     object_crops_list = []
#     selected_idx = []
    
def extract_cropped_images_and_labels(inputs, rcnn_model, device, preprocess, coco_id_name_map, batch_idx, output_dir="cropped_dataset"):
    rcnn_model.eval()
    with torch.no_grad():
        outputs = rcnn_model(inputs)
        print(f"Outputs: {outputs}")

    # 获取检测到的目标类别
    rcnn_boxes = outputs[0]["instances"].pred_boxes.tensor.to("cuda") if len(outputs[0]["instances"]) > 0 else torch.tensor([])
    rcnn_classes = outputs[0]["instances"].pred_classes.to("cuda") if len(outputs[0]["instances"]) > 0 else torch.tensor([])

    # 如果没有检测到目标，直接返回 None
    if rcnn_classes.numel() == 0:
        print("No objects detected, skipping image.")
        return None, None

    img = inputs[0]["image"].to(device)
    new_height, new_width = img.shape[1], img.shape[2]
    object_crops_list = []
    selected_idx = []
    for bbox_idx, bbox in enumerate(rcnn_boxes):
        x1, y1, x2, y2 = bbox.int()
    
        # 调整裁剪区域的坐标
        x1 = max(0, int(x1 * new_width / inputs[0]['width']))
        x2 = min(new_width, int(x2 * new_width / inputs[0]['width']))
        y1 = max(0, int(y1 * new_height / inputs[0]['height']))
        y2 = min(new_height, int(y2 * new_height / inputs[0]['height']))
    
        # 确保裁剪区域有效且大小合理
        if x2 > x1 and y2 > y1 and (x2 - x1) > 1 and (y2 - y1) > 1:
            cropped_image = img[:, y1:y2, x1:x2]
            cropped_img_arr = cropped_image.permute(1, 2, 0).cpu().numpy()
    
            if cropped_img_arr.shape[0] > 0 and cropped_img_arr.shape[1] > 0:
                # 将浮点型数组转换为 uint8 类型
                cropped_img_arr = (cropped_img_arr * 255).astype(np.uint8)
                cropped_img_arr = cv2.cvtColor(cropped_img_arr, cv2.COLOR_BGR2RGB)  # 转换为 RGB
                img_pil = Image.fromarray(cropped_img_arr)
                image = preprocess(img_pil).unsqueeze(0).to(device)
    
                object_crops_list.append(image)
                # 使用 coco_id_name_map 将类别索引映射为类别名称
                class_name = coco_id_name_map.get(rcnn_classes[bbox_idx].item())
                selected_idx.append(class_name)

    if object_crops_list:
        cropped_img_arr = torch.cat(object_crops_list, dim=0)
        return cropped_img_arr, selected_idx
    else:
        return None, None



# 定义加载 CLIP 模型的函数
def load_clip_model(device):
    clip_model, _, preprocess = open_clip.create_model_and_transforms('ViT-SO400M-14-SigLIP', pretrained='webli')
    tokenizer = open_clip.get_tokenizer('ViT-SO400M-14-SigLIP')
    clip_model = clip_model.to(device)
    return clip_model, tokenizer, preprocess


# 定义加载 Faster R-CNN 模型的函数
def load_fully_supervised_trained_model(cfg_file, weight_dir):
    # Load the model weights of supervised training phase
    opts = [f'train.output_dir={weight_dir}', f'train.init_checkpoint={weight_dir}/model_final.pth']

    cfg = LazyConfig.load(cfg_file)
    cfg = LazyConfig.apply_overrides(cfg, opts)
    default_setup(cfg, None)

    model = instantiate(cfg.model)
    model.to(cfg.train.device)

    DetectionCheckpointer(model).load(cfg.train.init_checkpoint)
    return model, cfg


# 定义裁剪图像的数据集类
class CroppedImageDataset(Dataset):
    def __init__(self, images, labels, preprocess):
        self.images = images
        self.labels = labels
        self.preprocess = preprocess

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        while True:
            image = self.images[idx]
            label = self.labels[idx]

            # 确保 image 是一个 PIL 图像对象
            if isinstance(image, torch.Tensor):
                image = transforms.ToPILImage()(image)

            # 应用预处理
            image = self.preprocess(image)

            # 检查 label 是否为 None
            if label is None:
                # 如果 label 是 None，跳过该数据项
                idx = (idx + 1) % len(self.images)
                continue

            # 如果 label 不是 None，返回有效的数据
            return image, label



def finetune_clip_model(clip_model, dataloader,tokenizer, d_size, device, epochs=5, lr=1e-5, alpha=0.5):
    clip_model.train()
    zeroshot_weights = clip_model.state_dict()
    zeroshot_save_path = "./weights/CLIP_Weights/zeroshot_clip_model.pth"
    torch.save(zeroshot_weights, zeroshot_save_path)

    for param in clip_model.parameters():
        param.requires_grad = False

    for name, param in clip_model.text.named_parameters():
        if 'ln_final' in name or 'text_projection' in name:
            param.requires_grad = True

    for name, param in clip_model.visual.named_parameters():
        if 'ln_post' in name or 'proj' in name:
            param.requires_grad = True

    optimizer = optim.Adam(filter(lambda p: p.requires_grad, clip_model.parameters()), lr=lr, betas=(0.9, 0.98), eps=1e-6, weight_decay=0.001)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)
    loss_fn = nn.CrossEntropyLoss()

    losses = []
    accuracies = []

    for epoch in range(epochs):
        total_loss = 0
        correct = 0
        total = 0

        for batch_idx, (images, labels) in enumerate(dataloader):
            images = images.to(device)
            image_features = clip_model.encode_image(images)

            # 将类别名称（字符串）转换为文本嵌入
            texts = tokenizer(labels).to(device)  
            text_features = clip_model.encode_text(texts)

            optimizer.zero_grad()
 
            image_features = F.normalize(image_features, dim=-1)
            

            logits_per_image = image_features @ text_features.T * clip_model.logit_scale.exp()

            ground_truth = torch.arange(len(images), dtype=torch.long, device=device)  # 对角线匹配
            loss = loss_fn(logits_per_image, ground_truth)
            total_loss += loss.item()

            loss.backward()
            optimizer.step()

            predictions = torch.argmax(logits_per_image, dim=1)
            correct += (predictions == ground_truth).sum().item()
            total += len(images)

            if batch_idx % 100 == 0:
                print(f'Train epoch:{epoch} batch:{batch_idx} loss:{loss.item():.4f}')

        epoch_loss = total_loss / len(dataloader)
        epoch_accuracy = correct / total
        losses.append(epoch_loss)
        accuracies.append(epoch_accuracy)

        print(f'Train epoch:{epoch} Loss: {epoch_loss:.4f}, Accuracy: {epoch_accuracy:.4f}')
        scheduler.step()

        torch.save(clip_model.state_dict(), f"weights/CLIP_Weights/In_train_weights/LM_epoch_{epochs}_dsize_{d_size}.pth")
        print(f"Model weights saved at epoch {epoch}")

    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.plot(range(epochs), losses, label="Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Training Loss Curve")
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.plot(range(epochs), accuracies, label="Accuracy")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.title("Training Accuracy Curve")
    plt.legend()

    if d_size is not None:
        plt.savefig(f"Training_Results/LM_training_curve_epoch_{epochs}_dsize_{d_size}.png")
    else:
        plt.savefig(f"Training_Results/LM_training_curve.png")
    print(f"Training curve saved as training_curve_epoch_{epochs}_dsize_{d_size}.png")

    finetuned_weights = clip_model.state_dict()
    wise_ft_weights = {
        key: (1 - alpha) * zeroshot_weights[key] + alpha * finetuned_weights[key]
        for key in zeroshot_weights.keys()
    }

    clip_model.load_state_dict(wise_ft_weights)
    torch.save(clip_model.state_dict(), f"weights/CLIP_Weights/www/LM_wft_epoch_{epochs}_dsize_{d_size}.pth")
    print("Final model weights saved with WiSE-FT applied.")

    return clip_model




def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 配置路径
    proj_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
    sys.path.append(proj_path)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(script_dir, "params.json")
    coco_id_name_map = {
        1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorcycle', 5: 'airplane', 6: 'bus', 7: 'train', 8: 'truck', 9: 'boat', 10: 'traffic light',
        11: 'fire hydrant', 13: 'stop sign', 14: 'parking meter', 15: 'bench', 16: 'bird', 17: 'cat', 18: 'dog', 19: 'horse', 20: 'sheep',
        21: 'cow', 22: 'elephant', 23: 'bear', 24: 'zebra', 25: 'giraffe', 27: 'backpack', 28: 'umbrella', 31: 'handbag', 32: 'tie', 33: 'suitcase',
        34: 'frisbee', 35: 'skis', 36: 'snowboard', 37: 'sports ball', 38: 'kite', 39: 'baseball bat', 40: 'baseball glove', 41: 'skateboard',
        42: 'surfboard', 43: 'tennis racket', 44: 'bottle', 46: 'wine glass', 47: 'cup', 48: 'fork', 49: 'knife', 50: 'spoon', 51: 'bowl',
        52: 'banana', 53: 'apple', 54: 'sandwich', 55: 'orange', 56: 'broccoli', 57: 'carrot', 58: 'hot dog', 59: 'pizza', 60: 'donut',
        61: 'cake', 62: 'chair', 63: 'couch', 64: 'potted plant', 65: 'bed', 67: 'dining table', 70: 'toilet', 72: 'tv', 73: 'laptop',
        74: 'mouse', 75: 'remote', 76: 'keyboard', 77: 'cell phone', 78: 'microwave', 79: 'oven', 80: 'toaster', 81: 'sink',
        82: 'refrigerator', 84: 'book', 85: 'clock', 86: 'vase', 87: 'scissors', 88: 'teddy bear', 89: 'hair drier', 90: 'toothbrush',100:'background'
    }
    with open(params_path, "r") as f:
        params = json.load(f)

    cfg_file = params["cfg_file"]
    rcnn_weight_dir = params["rcnn_weight_dir"]
    data_split = params["data_split"]

    # 加载 CLIP 模型
    clip_model, tokenizer, preprocess = load_clip_model(device)
    clip_model = clip_model.to(device)

    # 加载 Faster R-CNN 模型
    rcnn_model, cfg = load_fully_supervised_trained_model(cfg_file, rcnn_weight_dir)
    rcnn_model.to(device)

    # 创建 Dataset 和 DataLoader
    dataset = LabelmeDataset(root_dir='Labelme/train', preprocess=preprocess)
    print(f"Dataset size: {len(dataset)}")  # 打印数据集大小
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True, num_workers=0, pin_memory=True)
    d_size = 5
    truncated_loader = truncate_dataloader(dataloader, d_size)

    # 初始化裁剪图像列表和标签列表
    cropped_images_list = []
    selected_idx_list = []


    for batch_idx, batch in enumerate(tqdm(truncated_loader, desc="Processing batches", unit="batch")):
        images = batch  # 直接使用 batch 中的图像
    
        inputs = [{"image": image, "height": image.shape[1], "width": image.shape[2]} for image in images]
    
        # 将每个输入字典中的张量移动到设备
        inputs = [{k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in item.items()} for item in inputs]

    
        cropped_images, selected_idx = extract_cropped_images_and_labels(inputs, rcnn_model, device, preprocess, coco_id_name_map, batch_idx)
        if cropped_images is not None and selected_idx is not None:
            cropped_images_list.append(cropped_images)
            selected_idx_list.append(selected_idx)

    output_dir = "Label_me_cropped_dataset"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    for batch_idx, (cropped_images, selected_idx) in enumerate(zip(cropped_images_list, selected_idx_list)):
        for img_idx, (image, label) in enumerate(zip(cropped_images, selected_idx)):
            image_filename = os.path.join(output_dir, f"images/{batch_idx}_{img_idx}.jpg")
            label_filename = os.path.join(output_dir, f"labels/{batch_idx}_{img_idx}.txt")
            image_pil = TF.to_pil_image(image.cpu())
            image_pil.save(image_filename)
            with open(label_filename, "w") as f:
                f.write(str(label))

        # 创建裁剪图像的数据集和 DataLoader
        cropped_dataset = CroppedImageDataset(cropped_images, selected_idx, preprocess)
        cropped_dataloader = DataLoader(cropped_dataset, batch_size=32, shuffle=True, num_workers=0, pin_memory=True, collate_fn=custom_collate_fn)

        # 微调 CLIP 模型
        finetuned_clip_model = finetune_clip_model(clip_model, cropped_dataloader, tokenizer, None, device, epochs=5, lr=1e-5, alpha=0.5)
    else:
        logger.info("No valid cropped images found. Skipping fine-tuning.")

if __name__ == "__main__":
    main()