import os
import sys
import torch
import json
from loguru import logger
from detectron2.config import LazyConfig, instantiate
from detectron2.engine import default_setup
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.data import build_detection_test_loader, get_detection_dataset_dicts, DatasetMapper
from detectron2.evaluation import  inference_on_dataset
import detectron2.data.transforms as T

current_script_dir = os.path.dirname(os.path.abspath(__file__))


project_root = os.path.abspath(os.path.join(current_script_dir, "../../.."))

# Add the project root to sys.path
sys.path.insert(0, project_root) # Insert at the beginning to prioritize

from datasets.register_coco_ovd_dataset import coco_meta # to register the OVD datasets
from scripts.open_vocab_detection.coco_eval_utils.Mcnn_coco_evaluator import McnnCOCOEvaluator
from scripts.open_vocab_detection.coco_eval_utils.coco_ovd_split import categories_seen, categories_unseen




def load_fully_supervised_trained_model(cfg_file, weight_dir, device):
    """
    Loads a Mask R-CNN model trained with full supervision.
    """
    opts = [f'train.output_dir={weight_dir}', f'train.init_checkpoint={weight_dir}/model_final.pth']

    cfg = LazyConfig.load(cfg_file)
    cfg = LazyConfig.apply_overrides(cfg, opts)
    
    # Set the device for evaluation
    cfg.train.device = device 
    default_setup(cfg, None)

    model = instantiate(cfg.model)
    model.to(cfg.train.device)

    DetectionCheckpointer(model).load(cfg.train.init_checkpoint)
    model.eval() # Set model to evaluation mode
    return model, cfg



def evaluate_mask_rcnn_performance(model, cfg, data_split, output_dir="eval_output"):
    """
    Evaluates the Mask R-CNN model on the specified dataset split and
    prints AP and Recall metrics.

    Args:
        model: The trained Mask R-CNN model.
        cfg: The Detectron2 configuration object.
        data_split: The name of the dataset split (e.g., "coco_2017_val").
        output_dir: Directory to save evaluation results.
    """
    os.makedirs(output_dir, exist_ok=True)
    
    test_loader = build_detection_test_loader(
        dataset = get_detection_dataset_dicts(names = data_split, filter_empty=False),
        mapper= DatasetMapper(
            is_train = False,
            augmentations=[
                T.ResizeShortestEdge(short_edge_length=800, max_size=1333),
            ],
            image_format="BGR",
        ),
        num_workers=4,
    )

    # Instantiate your CustomCOCOEvaluator and explicitly specify tasks
    # For Mask R-CNN, you typically want "bbox" and "segm"
    evaluator = McnnCOCOEvaluator(data_split, output_dir=output_dir, tasks=("bbox", "segm"))


    # Perform inference and evaluation
    logger.info(f"Starting evaluation on {data_split}...")
    results = inference_on_dataset(model, test_loader, evaluator)
    logger.info("Evaluation complete.")

    # Print the evaluation results
    logger.info(f"Evaluation Results for {data_split}:")
    logger.info(results)


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    proj_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
    sys.path.append(proj_path)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(script_dir, "mparam.json")
    with open(params_path, "r") as f:
        params = json.load(f)

    cfg_file = params["cfg_file"]
    rcnn_weight_dir = params["rcnn_weight_dir"]

    eval_data_split = params["data_split"]
    # Load Mask R-CNN model
    rcnn_model, cfg = load_fully_supervised_trained_model(cfg_file, rcnn_weight_dir, device)

    # Evaluate the Mask R-CNN model
    evaluate_mask_rcnn_performance(rcnn_model, cfg, eval_data_split)





if __name__ == "__main__":
    main()